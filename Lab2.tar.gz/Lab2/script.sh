current_time=$(date +%s)
echo "current time: $current_time"
for i in {1..20}
do 
	echo "Number: $i"	
done
	
